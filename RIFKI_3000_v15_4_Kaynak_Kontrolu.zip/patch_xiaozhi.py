#!/usr/bin/env python3
"""RIFKI 3000 v15.4: guarded SOURCE-ONLY compatibility patch.

This is not firmware and never flashes a device. Supports the observed bool
SetEmotion API and the older void signature. Tested on source excerpts and
synthetic fixtures, NOT on a full upstream checkout or the ESP32 toolchain.
Use --check for a non-mutating compatibility check.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

VERSION = 'v15.4-source-check'
STAMP = '.rifki-v15.4-source-check.json'
NAMES = ('main/display/display.h', 'main/display/oled_display.h',
         'main/display/oled_display.cc', 'main/application.cc')
HEADERS = ('rifki_face_core.h', 'rifki_face_overlay.h')

class PatchError(RuntimeError):
    pass

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def unique(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise PatchError(f'{label}: expected one anchor, found {count}; no source writes')
    return text.replace(old, new, 1)

def method_span(text: str, signature: str) -> tuple[int, int]:
    """Find a balanced C++ function, ignoring ordinary strings and comments."""
    start = text.find(signature)
    if start < 0 or text.count(signature) != 1:
        raise PatchError(f'Unexpected method signature: {signature}')
    opening = text.find('{', start)
    level, i = 0, opening
    quote = None
    while i < len(text):
        ch = text[i]
        if quote:
            if ch == '\\':
                i += 2
                continue
            if ch == quote:
                quote = None
        elif text.startswith('//', i):
            j = text.find('\n', i)
            i = len(text) if j < 0 else j
            continue
        elif text.startswith('/*', i):
            j = text.find('*/', i + 2)
            if j < 0:
                raise PatchError('Unclosed C++ comment')
            i = j + 2
            continue
        elif ch in ('"', "'"):
            quote = ch
        elif ch == '{':
            level += 1
        elif ch == '}':
            level -= 1
            if level == 0:
                return start, i + 1
        i += 1
    raise PatchError(f'Unclosed method: {signature}')

def make_plan(root: Path, package: Path) -> dict[str, bytes]:
    # Validate every input before writing ANY file.
    headers = {}
    for name in HEADERS:
        path = package / name
        if not path.is_file():
            raise PatchError(f'Missing package header: {name}; no source writes')
        headers[f'main/display/{name}'] = path.read_bytes()
    sources = {}
    for name in NAMES:
        p = root / name
        if not p.is_file() or p.is_symlink():
            raise PatchError(f'Missing source or symlink: {name}')
        sources[name] = p.read_text(encoding='utf-8')
    if any('rifki_face_' in text or 'SetSpeaking(' in text for text in sources.values()):
        raise PatchError('Existing/partial face integration detected; use clean source, not a second patch')
    f = NAMES[0]
    match = re.findall(r'    virtual (bool|void) SetEmotion\(const char\* emotion\);', sources[f])
    if len(match) != 1:
        raise PatchError('Unknown Display::SetEmotion signature')
    ret = match[0]
    decl = f'    virtual {ret} SetEmotion(const char* emotion);'
    sources[f] = unique(sources[f], decl, decl + '\n    virtual void SetSpeaking(bool speaking) { (void)speaking; }', f)

    f = NAMES[1]
    sources[f] = unique(sources[f], '#include "lvgl_display.h"', '#include "lvgl_display.h"\n#include <memory>', f)
    sources[f] = unique(sources[f], 'class OledDisplay : public LvglDisplay {',
                        'namespace rifki { class FaceOverlay; }\n\nclass OledDisplay : public LvglDisplay {', f)
    sources[f] = unique(sources[f], '    lv_obj_t* chat_message_label_ = nullptr;',
                        '    lv_obj_t* chat_message_label_ = nullptr;\n    std::unique_ptr<rifki::FaceOverlay> rifki_face_;', f)
    decl = f'    virtual {ret} SetEmotion(const char* emotion) override;'
    sources[f] = unique(sources[f], decl, decl + '\n    void SetSpeaking(bool speaking) override;', f)

    f = NAMES[2]
    sources[f] = unique(sources[f], '#include "oled_display.h"', '#include "oled_display.h"\n#include "rifki_face_overlay.h"', f)
    sources[f] = unique(sources[f], '        SetupUI_128x64();',
        '        SetupUI_128x64();\n'
        '        DisplayLockGuard rifki_lock(this);\n'
        '        if (rifki_lock && width_ == rifki::Face::W && height_ == rifki::Face::H)\n'
        '            rifki_face_ = std::make_unique<rifki::FaceOverlay>();', f)
    # A lock failure is fatal rather than allowing a timer-backed overlay to be
    # destroyed after LVGL teardown. This policy still requires ESP-IDF review.
    sources[f] = unique(sources[f], 'OledDisplay::~OledDisplay() {',
        'OledDisplay::~OledDisplay() {\n'
        '    if (rifki_face_) {\n'
        '        DisplayLockGuard rifki_lock(this);\n'
        '        if (!rifki_lock) {\n'
        '            ESP_LOGE("RIFKI", "Display cleanup lock failed");\n'
        '            std::abort();\n'
        '        }\n'
        '        rifki_face_.reset();\n'
        '    }', f)
    signature = f'{ret} OledDisplay::SetEmotion(const char* emotion) {{'
    start, end = method_span(sources[f], signature)
    block = sources[f][start:end]
    block = unique(block, '    DisplayLockGuard lock(this);\n', '', 'OLED emotion lock')
    rejected = 'return false;' if ret == 'bool' else 'return;'
    accepted = 'return true;' if ret == 'bool' else 'return;'
    prefix = (signature + '\n    DisplayLockGuard lock(this);\n'
              f'    if (!lock || emotion == nullptr) {rejected}\n'
              f'    if (rifki_face_ && rifki_face_->OnEmotion(emotion)) {accepted}\n'
              '    if (rifki_face_) rifki_face_->Hide();\n'
              f'    if (current_theme_ == nullptr) {rejected}')
    block = unique(block, signature, prefix, 'OLED emotion entry')
    sources[f] = sources[f][:start] + block + sources[f][end:]
    anchor = 'void OledDisplay::SetTheme(Theme* theme) {'
    sources[f] = unique(sources[f], anchor,
        'void OledDisplay::SetSpeaking(bool speaking) {\n'
        '    DisplayLockGuard lock(this);\n'
        '    if (lock && rifki_face_) rifki_face_->OnSpeaking(speaking);\n'
        '}\n\n' + anchor, f)

    f = NAMES[3]
    start, end = method_span(sources[f], 'void Application::HandleStateChangedEvent() {')
    block = sources[f][start:end]
    if not re.search(r'\bDeviceState\s+new_state\s*=\s*state_machine_\.GetState\(\);', block):
        raise PatchError('State-machine signature changed')
    anchor = '    auto display = board.GetDisplay();\n    auto led = board.GetLed();\n    led->OnStateChanged();'
    block = unique(block, anchor,
        '    auto display = board.GetDisplay();\n    auto led = board.GetLed();\n'
        '    // RIFKI: follow application state, including interruption/disconnection.\n'
        '    display->SetSpeaking(new_state == kDeviceStateSpeaking);\n'
        '    led->OnStateChanged();', 'state handler')
    sources[f] = sources[f][:start] + block + sources[f][end:]
    if 'display->SetEmotion(emotion_str.c_str())' not in sources[f]:
        raise PatchError('Expected LLM emotion dispatch not found')
    result = {name: data.encode('utf-8') for name, data in sources.items()}
    result.update(headers)
    return result

def apply(root: Path, package: Path, check: bool = False) -> str:
    root, package = root.resolve(), package.resolve()
    marker = root / STAMP
    if marker.exists():
        saved = json.loads(marker.read_text(encoding='utf-8'))
        for name, expected in saved['output_sha256'].items():
            p = root / name
            if not p.is_file() or digest(p.read_bytes()) != expected:
                raise PatchError('Patched source changed; refusing to overwrite edits')
        for name in HEADERS:
            p = package / name
            if not p.is_file() or digest(p.read_bytes()) != saved['output_sha256'][f'main/display/{name}']:
                raise PatchError('Local headers differ from the recorded patch')
        return 'ALREADY_APPLIED: source hashes match; nothing written'
    plan = make_plan(root, package)
    for name in HEADERS:
        p = root / 'main/display' / name
        if p.exists():
            raise PatchError(f'Untracked local header exists: {p.name}; refusing overwrite')
    backups = {name: (root / name).read_bytes() for name in NAMES}
    for name in NAMES:
        if (root / (name + '.rifki-v15.4-backup')).exists():
            raise PatchError('A previous backup exists; refusing an ambiguous source state')
    if check:
        return 'CHECK_OK: source anchors match; no files changed; not compiled'
    manifest = {'version': VERSION, 'input_sha256': {n: digest(b) for n, b in backups.items()},
                'output_sha256': {n: digest(b) for n, b in plan.items()},
                'scope': 'Source patch only; no ESP32 compilation or hardware validation'}
    created = []
    try:
        for name, data in backups.items():
            path = root / (name + '.rifki-v15.4-backup')
            path.write_bytes(data)
            created.append(path)
        for name, data in plan.items():
            path = root / name
            if name not in backups:
                created.append(path)
            path.write_bytes(data)
        marker.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    except OSError:
        # Best-effort rollback for I/O failures; not crash-safe transactional storage.
        for name, data in backups.items():
            (root / name).write_bytes(data)
        for path in created:
            path.unlink(missing_ok=True)
        marker.unlink(missing_ok=True)
        raise
    return 'PATCH_APPLIED: source only; NOT compiled for ESP32-S3; do not flash'

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_root', type=Path)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    try:
        print(apply(args.source_root, Path(__file__).parent, args.check))
        return 0
    except (PatchError, OSError, UnicodeError, ValueError, KeyError) as exc:
        print(f'STOP: {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
