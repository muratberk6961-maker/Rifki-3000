#include "rifki_face_overlay.h"
#include <cassert>
#include <cstring>
#include <iostream>
int main() {
  rifki::FaceOverlay f;
  assert(f.OnEmotion("happy"));
  assert(!f.OnEmotion("invalid_emotion"));
  f.Hide();
  f.OnSpeaking(true);
  f.OnSpeaking(false);
  assert(!f.OnEmotion("neutral"));
  for (auto name : rifki::Face::kNames) {
    if (std::strcmp(name, "normal") != 0) assert(f.OnEmotion(name));
  }
  std::cout << "PASS: overlay responds to 27 emotion names, neutral, speech start/stop.\n";
}
