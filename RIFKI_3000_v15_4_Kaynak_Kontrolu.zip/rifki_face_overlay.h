#pragma once
// RIFKI 3000: LVGL 9 OLED face overlay used by official XiaoZhi OledDisplay.
// Must only be called with the display/LVGL mutex held (except timer callback).
#include "rifki_face_core.h"
#include <lvgl.h>
#include <array>
#include <cstring>

namespace rifki {
class FaceOverlay {
public:
    FaceOverlay() {
        canvas_ = lv_canvas_create(lv_screen_active());
        if (!canvas_) return;
        lv_canvas_set_buffer(canvas_, buffer_.data(), Face::W, Face::H, LV_COLOR_FORMAT_I1);
        lv_canvas_set_palette(canvas_, 0, lv_color_to_32(lv_color_black(), LV_OPA_COVER));
        lv_canvas_set_palette(canvas_, 1, lv_color_to_32(lv_color_white(), LV_OPA_COVER));
        lv_obj_set_pos(canvas_, 0, 0);
        lv_obj_add_flag(canvas_, LV_OBJ_FLAG_HIDDEN);
        lv_obj_move_foreground(canvas_);
        timer_ = lv_timer_create(&FaceOverlay::OnTimer, 100, this);
        if (timer_) lv_timer_pause(timer_);
    }
    ~FaceOverlay() {
        if(timer_) {lv_timer_delete(timer_);timer_=nullptr;}
        if(canvas_) {lv_obj_delete(canvas_);canvas_=nullptr;}
    }
    // Only genuine recognized emotion codes replace the stock UI.
    bool OnEmotion(const char* emotion) {
        if (!canvas_ || !face_.OnEmotion(emotion)) return false;
        if (face_.CurrentEmotion()==Face::NORMAL && !face_.IsSpeaking()) {
            Hide(); // Restore the stock idle/activation display.
            return false;
        }
        Show();
        Draw();
        return true;
    }
    void OnSpeaking(bool enabled) {
        face_.OnSpeaking(enabled);
        if (!canvas_) return;
        if (enabled) Show();
        // When speech stops and no emotion is active, restore the stock XiaoZhi UI.
        if (!enabled && face_.CurrentEmotion()==Face::NORMAL) {
            Hide();
            return;
        }
        if(shown_) Draw();
    }
    void Hide() {
        if (!canvas_) return;
        shown_=false;
        lv_obj_add_flag(canvas_, LV_OBJ_FLAG_HIDDEN);
        if(timer_) lv_timer_pause(timer_);
    }
private:
    Face face_;
    // Indexed 1-bit canvas stores 2 colors (8-byte palette) + 128x64 packed pixels.
    alignas(4) std::array<uint8_t,8+Face::W*Face::H/8> buffer_{};
    lv_obj_t* canvas_=nullptr;
    lv_timer_t* timer_=nullptr;
    bool shown_=false;
    void Show() {
        if (!canvas_) return;
        shown_=true;
        lv_obj_move_foreground(canvas_);
        lv_obj_remove_flag(canvas_, LV_OBJ_FLAG_HIDDEN);
        if(timer_) lv_timer_resume(timer_);
    }
    void Draw() {
        if(!canvas_ || !shown_)return;
        face_.Render(lv_tick_get());
        const auto& pixels=face_.Bitmap();
        std::memcpy(buffer_.data()+8,pixels.data(),pixels.size());
        lv_obj_invalidate(canvas_);
    }
    static void OnTimer(lv_timer_t* t) {
        auto* obj=static_cast<FaceOverlay*>(lv_timer_get_user_data(t));
        if(obj)obj->Draw(); // LVGL's timer already executes under LVGL thread.
    }
};
} // namespace rifki
