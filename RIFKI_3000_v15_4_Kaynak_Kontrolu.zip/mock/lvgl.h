#pragma once
#include <cstdint>
struct lv_obj_t { bool hidden=false; void* buf=nullptr; };
struct lv_timer_t { bool paused=false; void(*cb)(lv_timer_t*)=nullptr; void* data=nullptr; };
struct lv_color_t { uint8_t red,green,blue; };
struct lv_color32_t { uint8_t red,green,blue,alpha; };
constexpr int LV_COLOR_FORMAT_I1=1;
constexpr int LV_OBJ_FLAG_HIDDEN=1;
constexpr int LV_OPA_COVER=255;
inline lv_obj_t* lv_screen_active(){static lv_obj_t a;return &a;}
inline lv_obj_t* lv_canvas_create(lv_obj_t*){return new lv_obj_t;}
inline void lv_canvas_set_buffer(lv_obj_t* p,void* b,int,int,int){p->buf=b;}
inline lv_color_t lv_color_black(){return {0,0,0};}
inline lv_color_t lv_color_white(){return {255,255,255};}
inline lv_color32_t lv_color_to_32(lv_color_t c,uint8_t a){return {c.red,c.green,c.blue,a};}
inline void lv_canvas_set_palette(lv_obj_t*,int,lv_color32_t){}
inline void lv_obj_set_pos(lv_obj_t*,int,int){}
inline void lv_obj_add_flag(lv_obj_t* o,int){o->hidden=true;}
inline void lv_obj_remove_flag(lv_obj_t* o,int){o->hidden=false;}
inline void lv_obj_move_foreground(lv_obj_t*){}
inline lv_timer_t* lv_timer_create(void (*cb)(lv_timer_t*),int,void* p){return new lv_timer_t{false,cb,p};}
inline void lv_timer_pause(lv_timer_t* p){p->paused=true;}
inline void lv_timer_resume(lv_timer_t* p){p->paused=false;}
inline void lv_timer_delete(lv_timer_t* p){delete p;}
inline void lv_obj_delete(lv_obj_t* p){delete p;}
inline void lv_obj_invalidate(lv_obj_t*){}
inline uint32_t lv_tick_get(){return 1000;}
inline void* lv_timer_get_user_data(lv_timer_t* p){return p->data;}
