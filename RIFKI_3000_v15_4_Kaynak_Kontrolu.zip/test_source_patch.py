#!/usr/bin/env python3
"""New compatibility tests. Fixtures use observed upstream METHOD EXCERPTS.
The enclosing source tree is synthetic; this is NOT a full XiaoZhi build.
"""
from pathlib import Path
import json
import shutil
import subprocess
import tempfile
import unittest
import patch_xiaozhi as patch

HERE = Path(__file__).resolve().parent
# Observed on 2026-10-21 using the web reader; no commit SHA was available.
# Exact method excerpt: upstream main/display/oled_display.cc, lines 376-398
# in the browser's 1-based physical line convention.
BOOL_EMOTION = '''bool OledDisplay::SetEmotion(const char* emotion) {
    auto lvgl_theme = static_cast<LvglTheme*>(current_theme_);
    const char* utf8 = noto_emoji_get_utf8(emotion);
    const lv_font_t* emotion_font = lvgl_theme->emoji_font()->font();
    if (utf8 == nullptr) {
        utf8 = material_symbols_get_utf8(emotion);
        emotion_font = lvgl_theme->large_icon_font()->font();
    }
    DisplayLockGuard lock(this);
    if (emotion_label_ == nullptr) {
        return false;
    }
    if (utf8 != nullptr) {
        lv_obj_set_style_text_font(emotion_label_, emotion_font, 0);
        lv_label_set_text(emotion_label_, utf8);
        return true;
    }
    // Neither font has a glyph for this name, so what is shown is the neutral placeholder and
    // not the emotion that was asked for.
    lv_obj_set_style_text_font(emotion_label_, lvgl_theme->emoji_font()->font(), 0);
    lv_label_set_text(emotion_label_, NOTO_EMOJI_NEUTRAL);
    return false;
}'''
# Exact observed beginning of HandleStateChangedEvent. The closing brace in
# our fixture is synthetic, because the rest of the handler is not reproduced.
STATE_BEGIN = '''void Application::HandleStateChangedEvent() {
    DeviceState new_state = state_machine_.GetState();
    clock_ticks_ = 0;
    // Any state change invalidates a pending deferred listening start;
    // the Listening case below re-arms it when needed.
    pending_listening_start_ = false;

    auto& board = Board::GetInstance();
    auto display = board.GetDisplay();
    auto led = board.GetLed();
    led->OnStateChanged();
'''
SOURCES = {
    'main/display/display.h': 'class Display {\n    virtual bool SetEmotion(const char* emotion);\n};\n',
    'main/display/oled_display.h': '''#include "lvgl_display.h"
class OledDisplay : public LvglDisplay {
    lv_obj_t* chat_message_label_ = nullptr;
    virtual bool SetEmotion(const char* emotion) override;
};
''',
    'main/display/oled_display.cc': '''#include "oled_display.h"
void OledDisplay::SetupUI() {
    if (height_ == 64) {
        SetupUI_128x64();
    } else {
        SetupUI_128x32();
    }
}
OledDisplay::~OledDisplay() {
}
''' + BOOL_EMOTION + '\nvoid OledDisplay::SetTheme(Theme* theme) {\n}\n',
    'main/application.cc': '''// Synthetic enclosing function; observed LLM dispatch preserved.
void Application::ExampleDispatch() {
    Schedule([display, emotion_str = std::string(emotion->valuestring)]() {
        display->SetEmotion(emotion_str.c_str());
    });
}
''' + STATE_BEGIN + '}\n',
}

def make_fixture(root: Path, return_type: str = 'bool') -> None:
    for name, text in SOURCES.items():
        if return_type == 'void':
            # Historical API fixture only, not an asserted historical checkout.
            text = text.replace('bool SetEmotion(', 'void SetEmotion(')
            text = text.replace('bool OledDisplay::SetEmotion(', 'void OledDisplay::SetEmotion(')
            text = text.replace('return false;', 'return;').replace('return true;', 'return;')
        p = root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding='utf-8')

def snapshot(root: Path) -> dict[str, bytes]:
    return {str(p.relative_to(root)): p.read_bytes() for p in root.rglob('*') if p.is_file()}

class SourcePatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / 'source'
        make_fixture(self.root)
    def tearDown(self):
        self.tmp.cleanup()
    def test_01_dry_run_does_not_write(self):
        before = snapshot(self.root)
        self.assertIn('CHECK_OK', patch.apply(self.root, HERE, check=True))
        self.assertEqual(before, snapshot(self.root))
    def test_02_current_bool_api_and_lock_order(self):
        patch.apply(self.root, HERE)
        text = (self.root / patch.NAMES[2]).read_text()
        a, b = patch.method_span(text, 'bool OledDisplay::SetEmotion(const char* emotion) {')
        body = text[a:b]
        self.assertEqual(body.count('DisplayLockGuard lock(this);'), 1)
        self.assertIn('if (!lock || emotion == nullptr) return false;', body)
        self.assertIn('if (rifki_face_ && rifki_face_->OnEmotion(emotion)) return true;', body)
        self.assertLess(body.index('if (!lock'), body.index('rifki_face_->OnEmotion'))
        self.assertLess(body.index('current_theme_ == nullptr'), body.index('auto lvgl_theme'))
    def test_03_old_void_api(self):
        make_fixture(self.root, 'void')
        patch.apply(self.root, HERE)
        text = (self.root / patch.NAMES[2]).read_text()
        a, b = patch.method_span(text, 'void OledDisplay::SetEmotion(const char* emotion) {')
        self.assertIn('if (!lock || emotion == nullptr) return;', text[a:b])
        self.assertNotIn('return true;', text[a:b])
    def test_04_repeat_is_byte_identical(self):
        patch.apply(self.root, HERE)
        before = snapshot(self.root)
        self.assertIn('ALREADY_APPLIED', patch.apply(self.root, HERE))
        self.assertEqual(before, snapshot(self.root))
    def test_05_unknown_source_has_no_writes(self):
        p = self.root / patch.NAMES[3]
        p.write_text(p.read_text().replace('led->OnStateChanged();', 'led->Changed();'))
        before = snapshot(self.root)
        with self.assertRaises(patch.PatchError):
            patch.apply(self.root, HERE)
        self.assertEqual(before, snapshot(self.root))
    def test_06_missing_header_has_no_writes(self):
        package = Path(self.tmp.name) / 'incomplete_package'
        package.mkdir()
        shutil.copy2(HERE / 'rifki_face_core.h', package)
        before = snapshot(self.root)
        with self.assertRaises(patch.PatchError):
            patch.apply(self.root, package)
        self.assertEqual(before, snapshot(self.root))
    def test_07_partial_patch_refused(self):
        p = self.root / patch.NAMES[0]
        p.write_text(p.read_text() + '\n// SetSpeaking( partial patch marker\n')
        before = snapshot(self.root)
        with self.assertRaises(patch.PatchError):
            patch.apply(self.root, HERE)
        self.assertEqual(before, snapshot(self.root))
    def test_08_modified_output_not_overwritten(self):
        patch.apply(self.root, HERE)
        p = self.root / patch.NAMES[0]
        p.write_text(p.read_text() + '\n// external local edit\n')
        before = snapshot(self.root)
        with self.assertRaises(patch.PatchError):
            patch.apply(self.root, HERE)
        self.assertEqual(before, snapshot(self.root))
    def test_09_real_state_anchor_and_dimensions(self):
        patch.apply(self.root, HERE)
        app = (self.root / patch.NAMES[3]).read_text()
        oled = (self.root / patch.NAMES[2]).read_text()
        self.assertEqual(app.count('display->SetSpeaking(new_state == kDeviceStateSpeaking);'), 1)
        self.assertIn('display->SetEmotion(emotion_str.c_str())', app)
        self.assertIn('width_ == rifki::Face::W && height_ == rifki::Face::H', oled)
        self.assertIn('std::abort();', oled)
    def test_10_patched_actual_method_compiles_and_runs_with_mocks(self):
        patch.apply(self.root, HERE)
        text = (self.root / patch.NAMES[2]).read_text()
        a, b = patch.method_span(text, 'bool OledDisplay::SetEmotion(const char* emotion) {')
        c, d = patch.method_span(text, 'void OledDisplay::SetSpeaking(bool speaking) {')
        wrapper = r'''
#include "rifki_face_overlay.h"
#include <cassert>
#include <memory>
#include <string>
#include <iostream>
// Explicit MOCKS: these are not real LVGL, ESP-IDF, or an OLED.
static bool lock_allowed = true;
static int font_lookups = 0, writes = 0;
struct lv_font_t {};
struct Font { const lv_font_t* font() const { static lv_font_t f; return &f; } };
struct Theme { virtual ~Theme() = default; };
struct LvglTheme : Theme {
    std::shared_ptr<Font> emoji_font() { return std::make_shared<Font>(); }
    std::shared_ptr<Font> large_icon_font() { return std::make_shared<Font>(); }
};
const char* noto_emoji_get_utf8(const char* e) {
    ++font_lookups;
    return std::string(e)=="neutral" ? "NEUTRAL" : nullptr;
}
const char* material_symbols_get_utf8(const char*) { ++font_lookups; return nullptr; }
void lv_obj_set_style_text_font(lv_obj_t*, const lv_font_t*, int) { ++writes; }
void lv_label_set_text(lv_obj_t*, const char*) { ++writes; }
#define NOTO_EMOJI_NEUTRAL "NEUTRAL"
struct OledDisplay {
    Theme* current_theme_ = nullptr;
    lv_obj_t* emotion_label_ = nullptr;
    std::unique_ptr<rifki::FaceOverlay> rifki_face_;
    bool SetEmotion(const char* emotion);
    void SetSpeaking(bool speaking);
};
struct DisplayLockGuard {
    explicit DisplayLockGuard(OledDisplay*) {}
    explicit operator bool() const { return lock_allowed; }
};
'''
        wrapper += text[a:b] + '\n' + text[c:d]
        wrapper += r'''
int main() {
    OledDisplay display;
    LvglTheme theme;
    lv_obj_t label;
    display.current_theme_ = &theme;
    display.emotion_label_ = &label;
    display.rifki_face_ = std::make_unique<rifki::FaceOverlay>();
    assert(display.SetEmotion("happy"));
    assert(font_lookups == 0 && writes == 0);
    lock_allowed = false;
    assert(!display.SetEmotion("sad"));
    display.SetSpeaking(true);
    assert(font_lookups == 0 && writes == 0);
    lock_allowed = true;
    assert(!display.SetEmotion(nullptr));
    assert(font_lookups == 0 && writes == 0);
    display.SetSpeaking(false);
    assert(display.SetEmotion("neutral"));
    assert(font_lookups == 1 && writes == 2);
    assert(!display.SetEmotion("invalid"));
    display.current_theme_ = nullptr;
    assert(!display.SetEmotion("invalid"));
    assert(display.SetEmotion("happy"));
    display.rifki_face_.reset();
    assert(!display.SetEmotion("happy"));
    std::cout << "PASS: patched upstream bool method + MOCK dependencies; NOT ESP32/LVGL build\n";
}
'''
        source = Path(self.tmp.name) / 'integration_fixture.cpp'
        binary = Path(self.tmp.name) / 'integration_fixture'
        source.write_text(wrapper)
        result = subprocess.run(['g++', '-std=c++17', '-Wall', '-Wextra', '-Werror',
                                 '-fsanitize=undefined', '-fno-sanitize-recover=all',
                                 '-I'+str(HERE), '-I'+str(HERE/'mock'), str(source), '-o', str(binary)],
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stderr)
        result = subprocess.run([str(binary)], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        print(result.stdout.strip())

if __name__ == '__main__':
    unittest.main(verbosity=2)
