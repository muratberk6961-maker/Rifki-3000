#pragma once
// RIFKI 3000: portable monochrome 128x64 eye renderer.
// Uses the 27 emotion definitions and drawing patterns of the v14.2 sketch.
// No Arduino dependencies: suitable for use inside the ESP-IDF XiaoZhi firmware.
#include <array>
#include <cstddef>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <cstdint>
#include <string>

namespace rifki {
class Face {
public:
    static constexpr int W = 128, H = 64;
    static constexpr int kEmotionCount = 27;
    enum Emotion : uint8_t {
        NORMAL, HAPPY, LAUGH, SAD, SURPRISED, ANGRY, AFRAID, CURIOUS, SLEEPY,
        LOVE, EXCITED, SHY, CONFUSED, WINK, PROUD, SERIOUS, WORRIED, BORED,
        CALM, GRATEFUL, HOPEFUL, DISGUSTED, JEALOUS, EMBARRASSED, AMAZED,
        THINKING, PLAYFUL
    };
    static constexpr const char* kNames[kEmotionCount] = {
       "normal", "happy", "laugh", "sad", "surprised", "angry", "afraid", "curious", "sleepy",
       "love", "excited", "shy", "confused", "wink", "proud", "serious", "worried", "bored",
       "calm", "grateful", "hopeful", "disgusted", "jealous", "embarrassed", "amazed",
       "thinking", "playful"
    };
    bool OnEmotion(const char* name) {
        if (!name) return false;
        // Server data is untrusted: do not allocate an unbounded emotion string.
        size_t len = 0;
        while (len <= 32 && name[len] != '\0') ++len;
        if (len == 0 || len > 32) return false;
        std::string s(name, len);
        std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c){return static_cast<char>(std::tolower(c));});
        const struct Alias { const char* label; Emotion e; } aliases[] = {
          {"neutral",NORMAL},{"laughing",LAUGH},{"surprise",SURPRISED},
          {"fearful",AFRAID},{"sleep",SLEEPY},{"loving",LOVE},{"winking",WINK}
        };
        for (int i=0;i<kEmotionCount;i++) if (s==kNames[i]) {emotion_=static_cast<Emotion>(i);return true;}
        for (auto& item:aliases) if (s==item.label) {emotion_=item.e;return true;}
        return false;
    }
    void OnSpeaking(bool speaking) { speaking_=speaking; }
    bool IsSpeaking() const { return speaking_; }
    Emotion CurrentEmotion() const { return emotion_; }
    void SetGaze(int8_t pixels) { gaze_=std::max<int8_t>(-5,std::min<int8_t>(5,pixels)); }
    const std::array<uint8_t, W*H/8>& Bitmap() const { return bitmap_; }
    void Render(uint32_t now) {
        // period ~4s, short blink; deterministic and wrap-safe.
        if (now-last_blink_ >= 4000) last_blink_=now;
        const bool blinking=(now-last_blink_<140);
        const uint8_t t=static_cast<uint8_t>(now/80);
        clear();
        int dx=gaze_==0?(int((t/5)%3)-1)*2:gaze_;
        int dy=int((t/9)%3)-1;
        bool closedL=false,closedR=false;
        int rx=11,ry=13, mouthMode=0, tiltL=0,tiltR=0;
        switch(emotion_) {
          case NORMAL: mouthMode=0;break;
          case HAPPY: closedL=closedR=true;mouthMode=1;break;
          case LAUGH: closedL=closedR=true;mouthMode=5;break;
          case SAD: tiltL=-5;tiltR=5;mouthMode=3;dy=3;break;
          case SURPRISED: rx=13;ry=18;mouthMode=2;break;
          case ANGRY: tiltL=5;tiltR=-5;ry=9;mouthMode=4;break;
          case AFRAID: rx=13;ry=17;mouthMode=2;dy=3;break;
          case CURIOUS: tiltL=-4;tiltR=0;dx=6;mouthMode=6;break;
          case SLEEPY: closedL=closedR=true;mouthMode=0;break;
          case LOVE: mouthMode=1;break;
          case EXCITED: rx=13;ry=16;mouthMode=5;break;
          case SHY: rx=10;ry=9;dy=4;mouthMode=1;break;
          case CONFUSED: tiltL=-4;tiltR=-4;dx=-5;mouthMode=6;break;
          case WINK: closedL=true;mouthMode=1;break;
          case PROUD: ry=9;tiltL=-2;tiltR=2;mouthMode=4;break;
          case SERIOUS: ry=9;mouthMode=0;break;
          case WORRIED: tiltL=-5;tiltR=5;rx=12;mouthMode=3;break;
          case BORED: ry=6;mouthMode=0;dx=4;break;
          case CALM: closedL=closedR=true;mouthMode=1;break;
          case GRATEFUL: closedL=closedR=true;mouthMode=5;break;
          case HOPEFUL: tiltL=-3;tiltR=3;dy=-3;mouthMode=1;break;
          case DISGUSTED: ry=7;tiltL=3;tiltR=-2;mouthMode=6;break;
          case JEALOUS: ry=8;dx=7;tiltL=4;tiltR=-3;mouthMode=4;break;
          case EMBARRASSED: rx=9;ry=10;dy=5;mouthMode=6;break;
          case AMAZED: rx=13;ry=17;mouthMode=5;break;
          case THINKING: ry=10;dx=7;tiltL=-4;mouthMode=6;break;
          case PLAYFUL: closedR=true;dx=-5;mouthMode=1;break;
        }
        if (blinking) closedL=closedR=true;
        for(int i=0;i<2;i++) {
            int x=i==0?34:94;
            if(i==0?closedL:closedR)
                closedEye(x,31,emotion_==HAPPY||emotion_==LAUGH||emotion_==CALM||emotion_==GRATEFUL);
            else eye(x,31,rx,ry,dx,dy);
            if(emotion_==ANGRY||emotion_==SAD||emotion_==CURIOUS||emotion_==CONFUSED||
               emotion_==WORRIED||emotion_==JEALOUS||emotion_==DISGUSTED||
               emotion_==THINKING||emotion_==HOPEFUL)
                eyebrow(x,11,i==0?tiltL:tiltR);
        }
        switch(emotion_) {
          case LAUGH: line(18,43,23,46);line(105,46,110,43);break;
          case AFRAID: line(13,18,13,27);line(115,18,115,27);break;
          case SLEEPY: line(110,7,117,7);line(117,7,110,14);break;
          case LOVE: fillCircle(14,15,3);fillCircle(114,15,3);break;
          case EXCITED: circle(14,13,3);circle(114,13,3);break;
          case SHY: circle(14,44,2);circle(114,44,2);break;
          case PROUD: line(16,15,26,13);line(102,13,112,15);break;
          case SERIOUS: line(18,15,44,15);line(84,15,110,15);break;
          case WORRIED: circle(115,20,3);line(115,24,114,28);break;
          case THINKING: circle(113,11,3);circle(120,6,2);break;
          case CALM: line(17,47,23,47);line(105,47,111,47);break;
          case GRATEFUL: line(11,49,20,46);line(108,46,117,49);break;
          case BORED: line(20,24,48,24);line(80,24,108,24);break;
          case EMBARRASSED: line(13,45,20,48);line(108,48,115,45);break;
          case AMAZED: circle(12,14,3);circle(116,14,3);break;
          case PLAYFUL: line(112,47,117,43);break;
          default:break;
        }
        if(speaking_) mouth(2,t%3); else mouth(mouthMode,0);
    }
private:
    std::array<uint8_t,W*H/8> bitmap_{};
    Emotion emotion_=NORMAL;
    bool speaking_=false;
    int8_t gaze_=0;
    uint32_t last_blink_=0;
    void clear() {bitmap_.fill(0);}
    void px(int x,int y) {
        if(x<0||x>=W||y<0||y>=H) return;
        const size_t off=static_cast<size_t>(y)*W+x;
        bitmap_[off/8]|=uint8_t(0x80>>(off%8));
    }
    void line(int x0,int y0,int x1,int y1) {
        int dx=std::abs(x1-x0),sx=x0<x1?1:-1,dy=-std::abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy;
        for(;;) {px(x0,y0);if(x0==x1&&y0==y1)break;int e2=2*err;
          if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}
    }
    void circle(int x,int y,int r) {
        int a=r,b=0,d=1-r;
        while(a>=b) {px(x+a,y+b);px(x+b,y+a);px(x-b,y+a);px(x-a,y+b);
          px(x-a,y-b);px(x-b,y-a);px(x+b,y-a);px(x+a,y-b);b++;
          if(d<0)d+=2*b+1;else{a--;d+=2*(b-a)+1;}}
    }
    void fillCircle(int x,int y,int r) {
       for(int yy=-r;yy<=r;yy++)for(int xx=-r;xx<=r;xx++)if(xx*xx+yy*yy<=r*r)px(x+xx,y+yy);
    }
    void eye(int cx,int cy,int rx,int ry,int dx,int dy) {
        // Rounded eye outline approximates v14.2's drawRoundRect on 128x64.
        const int x=cx-rx,y=cy-ry,w=2*rx,h=2*ry,r=std::min(rx,6);
        line(x+r,y,x+w-r-1,y);line(x+r,y+h-1,x+w-r-1,y+h-1);
        line(x,y+r,x,y+h-r-1);line(x+w-1,y+r,x+w-1,y+h-r-1);
        for(int a=0;a<=r;a++){
          const int b=int((r*r-a*a)>=0?std::sqrt(double(r*r-a*a)):0.0);
          px(x+r-a,y+r-b);px(x+w-1-r+a,y+r-b);
          px(x+r-a,y+h-1-r+b);px(x+w-1-r+a,y+h-1-r+b);
        }
        fillCircle(cx+dx,cy+dy,3);
    }
    void closedEye(int x,int y,bool smile) {
        if(smile) {line(x-12,y+2,x-6,y-2);line(x-6,y-2,x+6,y-2);line(x+6,y-2,x+12,y+2);}
        else line(x-12,y,x+12,y);
    }
    void eyebrow(int x,int y,int tilt) {line(x-11,y-tilt,x+11,y+tilt);}
    void mouth(int mode,int wobble) {
        switch(mode) {
          case 0:line(56,56,72,56);break;
          case 1:line(54,53,60,58);line(60,58,68,58);line(68,58,74,53);break;
          case 2:circle(64,55,5+wobble);break;
          case 3:line(54,59,60,54);line(60,54,68,54);line(68,54,74,59);break;
          case 4:line(55,55,63,52);line(63,52,73,56);break;
          case 5:for(int yy=52;yy<59;yy++)for(int xx=57;xx<71;xx++)px(xx,yy);break;
          case 6:line(56,56,61,53);line(61,53,66,58);line(66,58,72,54);break;
        }
    }
};
} // namespace rifki
