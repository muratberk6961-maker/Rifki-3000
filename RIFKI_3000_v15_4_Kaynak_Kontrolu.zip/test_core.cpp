#include "rifki_face_core.h"
#include <cassert>
#include <iostream>
#include <set>
#include <string>
static uint64_t hash_frame(const std::array<uint8_t,128*64/8>& b){uint64_t h=1469598103934665603ULL;for(auto v:b){h^=v;h*=1099511628211ULL;}return h;}
int main(){
 rifki::Face f;
 std::set<uint64_t> frames;
 for(int i=0;i<rifki::Face::kEmotionCount;i++) {
  assert(f.OnEmotion(rifki::Face::kNames[i]));f.Render(1000);
  uint64_t h=hash_frame(f.Bitmap());
  if(!frames.insert(h).second){std::cerr<<"Duplicate expression: "<<rifki::Face::kNames[i]<<"\n";return 1;}
 }
 assert(frames.size()==27);
 assert(f.OnEmotion("HAPPY"));
 assert(!f.OnEmotion("not-an-emotion"));
 f.Render(1000);auto before=hash_frame(f.Bitmap());
 f.OnSpeaking(true); f.Render(1000);auto during=hash_frame(f.Bitmap());
 assert(during!=before);
 f.OnSpeaking(false);assert(!f.IsSpeaking());
 f.OnEmotion("normal");f.SetGaze(5);f.Render(1000);auto right=hash_frame(f.Bitmap());
 f.SetGaze(-5);f.Render(1000);assert(right!=hash_frame(f.Bitmap()));
 std::cout<<"PASS: 27 unique frames, case folding, invalid emotion, speaking, gaze\n";
}
