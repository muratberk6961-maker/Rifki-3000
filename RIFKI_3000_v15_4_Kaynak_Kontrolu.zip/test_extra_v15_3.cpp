#include "rifki_face_core.h"
#include <array>
#include <cassert>
#include <cstring>
#include <iostream>
#include <set>
#include <string>
using rifki::Face;
static uint64_t h(const std::array<uint8_t,Face::W*Face::H/8>& a){uint64_t v=1469598103934665603ull;for(auto b:a){v^=b;v*=1099511628211ull;}return v;}
int main(){
  Face f;
  for (uint32_t t: {1000u, 5000u, 15555u, 0xFFFFFFF0u}) {
    std::set<uint64_t> frames;
    for (const char* name : Face::kNames){
      assert(f.OnEmotion(name)); f.OnSpeaking(false); f.SetGaze(0); f.Render(t);
      assert(frames.insert(h(f.Bitmap())).second);
    }
    std::cout << "27 unique expressions tick=" << t << "\n";
  }
  assert(f.OnEmotion("HAPPY"));
  assert(f.OnEmotion("neutral"));
  assert(!f.OnEmotion(""));
  assert(!f.OnEmotion(nullptr));
  assert(!f.OnEmotion("long-invalid-emotion-name-abcdef-123456789"));
  assert(!f.OnEmotion("notreal"));
  f.OnEmotion("normal"); f.Render(1000); const auto still=h(f.Bitmap());
  f.OnSpeaking(true); f.Render(1000); assert(still!=h(f.Bitmap()));
  f.OnSpeaking(false);
  f.SetGaze(-5); f.Render(2100);const auto l=h(f.Bitmap());
  f.SetGaze(5);f.Render(2100);assert(l!=h(f.Bitmap()));
  Face f2; f2.OnEmotion("normal"); f2.Render(3999); const auto bb=h(f2.Bitmap());
  f2.Render(4000);assert(bb!=h(f2.Bitmap()));
  std::cout << "PASS extra cases: aliases, invalid input, 27 unique times, voice, gaze, blink\n";
}
